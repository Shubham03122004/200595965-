using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using MvcCrudApp.Models;

namespace MvcCrudApp.Controllers
{
    public class StudentController : Controller
    {
        private static List<Student> students = new List<Student>
        {
            new Student { StudentId = 1, FirstName = "John", LastName = "Doe", EmailAddress = "john.doe@example.com" },
            new Student { StudentId = 2, FirstName = "Jane", LastName = "Smith", EmailAddress = null }
        };

        public IActionResult Index()
        {
            return View(students);
        }

        public IActionResult Create() => View();

        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (!ModelState.IsValid)
                return View(student);
            
            student.StudentId = students.Count + 1;
            students.Add(student);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var student = students.FirstOrDefault(s => s.StudentId == id);
            if (student == null) return NotFound();
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(int id, Student student)
        {
            if (!ModelState.IsValid)
                return View(student);
            
            var existingStudent = students.FirstOrDefault(s => s.StudentId == id);
            if (existingStudent == null) return NotFound();
            
            existingStudent.FirstName = student.FirstName;
            existingStudent.LastName = student.LastName;
            existingStudent.EmailAddress = student.EmailAddress;
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var student = students.FirstOrDefault(s => s.StudentId == id);
            if (student == null) return NotFound();
            return View(student);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var student = students.FirstOrDefault(s => s.StudentId == id);
            if (student == null) return NotFound();
            students.Remove(student);
            return RedirectToAction("Index");
        }
    }
}
